$sourcePath = "e:\Dev\OBS Delay"
$zipPath = "e:\Dev\OBS Delay\Stream-Delay-Manager.zip"

Write-Host "Creando ZIP en: $zipPath" -ForegroundColor Cyan

# Obtener lista de archivos excluyendo los pesados/innecesarios
$files = Get-ChildItem -Path $sourcePath -Exclude "node_modules", ".git", "*.zip", ".vscode", "dist" | Where-Object { $_.Name -ne "node_modules" -and $_.Name -ne ".git" -and $_.Name -ne "dist" }

# Comprimir
Compress-Archive -Path $files.FullName -DestinationPath $zipPath -Force

Write-Host "ZIP creado exitosamente!" -ForegroundColor Green
Write-Host "Archivos incluidos:"
$files.Name
